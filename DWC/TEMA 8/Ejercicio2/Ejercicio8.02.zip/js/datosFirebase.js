"use strict";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyC6Nywp21V0J1VBth6DYnOvkuLsWy2UVlU",

  authDomain: "lista-de-la-compra-35bc7.firebaseapp.com",

  projectId: "lista-de-la-compra-35bc7",

  storageBucket: "lista-de-la-compra-35bc7.appspot.com",

  messagingSenderId: "940579217061",

  appId: "1:940579217061:web:1fbed463cbb5db41b5774c",
};
const app = initializeApp(firebaseConfig);
export { app };
